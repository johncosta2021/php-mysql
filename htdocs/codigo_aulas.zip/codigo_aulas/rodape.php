<div class="footer text-center">
			&copy;Todos os diretos reservados
		</div>