<?php

	include "banco.php";
	
	
?>

Fazer mais alguma coisa aqui...