<?php

	//conex�o com MYSQL
	mysql_connect("localhost","root",""); // cria conex�o com o servidor MYSQL
	mysql_select_db("tecnico2021"); // seleciona o banco desejado
	
	
?>