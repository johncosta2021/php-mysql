<?php
        include "banco.php";
        //Aqui vai inserir usando o comando SQL insert
    ?>