    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <?php
        include "banco.php";
        
        //Aqui vai usar o comando SQL DELETE para deletar as informações
        echo"Aqui vai usar o comando SQL DELETE para deletar as informações";
        
    ?>