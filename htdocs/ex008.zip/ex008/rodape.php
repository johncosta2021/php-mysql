<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>crud</title>
  </head>
  <body> 
    <br>
    <footer>
      <div style="background-color: #1659bf; margin-top: 50px;">
        <div class="container text-white">
           <div class="row">
            <div class="col-md-6">
              <h4 >Acessos</h4>
              <ul class="list-unstyled" style="margin-left: 40px;">
                <li>PARFOR</li>
                <li>Pibid e Residência Pedagógica</li>
                <li>Prodocência</li>
                <li>LAPETRO</li>
                <li>CNPq</li>
                <li>Periódicos</li>
                <li>FADEX</li>
                <li>FINEP</li>
                <li>Desconectar da Rede</li>
              </ul>
            </div>
          
          <div class="col-md-6">
            <h4>Contatos Gerais</h4>
                <ul class="list-unstyled" style="margin-left: 40px;">
                  <li>Protocolo</li>
                  <li>Acesso à Informação</li>
                  <li>Ouvidoria</li>
                  <li>Sala de Imprensa</li>
                  <li>COVID-19</li>
                </ul>
          </div>
         </div>
        </div>
      </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>