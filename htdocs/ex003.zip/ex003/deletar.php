    <?php
        include "banco.php";
        //Aqui vai usar o comando SQL DELETE para deletar as informações
    ?>