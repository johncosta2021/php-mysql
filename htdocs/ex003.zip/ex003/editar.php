    <?php
        include "banco.php";
        //Aqui vai usar o comando SQL UPDATE
    ?>