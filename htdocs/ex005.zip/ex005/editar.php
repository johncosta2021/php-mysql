    <?php
        include "banco.php";
        //Aqui vai usar o comando SQL UPDATE
        echo"Aqui vai usar o comando SQL UPDATE";
    
    ?>
    