/*
SQLyog Community
MySQL - 5.1.41 : Database - avaliacao23092021
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `celulares` */

DROP TABLE IF EXISTS `celulares`;

CREATE TABLE `celulares` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `modelo` varchar(15) NOT NULL,
  `Marca` varchar(8) NOT NULL,
  `Memoria_Interna` int(11) NOT NULL,
  `Memoria_Ram` int(11) NOT NULL,
  `Preco` int(11) NOT NULL,
  `Cor` varchar(10) NOT NULL,
  `Dual_sim` varchar(3) NOT NULL,
  `tamanho_da_tela` float NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `celulares` */

insert  into `celulares`(`Id`,`modelo`,`Marca`,`Memoria_Interna`,`Memoria_Ram`,`Preco`,`Cor`,`Dual_sim`,`tamanho_da_tela`) values 
(1,'poco x3','xiaomi',128,6,1700,'azul','sim',6.02),
(2,'redmi 9i','xiaomi',128,4,1920,'preto','sim',6.25),
(3,'iphone 8 plus','apple',64,4,3220,'branco','sim',5.65),
(4,'G 10 Power','motorola',64,4,1132,'preto','sim',6.5),
(5,'Galaxy s10 plus','samsung',64,6,2000,'Dourado','sim',5.65),
(6,'j5','samsung',32,2,920,'branco','sim',5);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
